#Q1
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Q2
lambda <- 1/3

pexp(2, rate = lambda)

#Q3
mean <- 100
sd <- 15

# i.
1 - pnorm(130, mean = mean, sd = sd)

# ii. 
qnorm(0.95, mean = mean, sd = sd)
